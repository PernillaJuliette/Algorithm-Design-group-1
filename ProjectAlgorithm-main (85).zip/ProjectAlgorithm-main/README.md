# gh-pages-about-me
A simple web page to teach students how to publish web content using GitHub Pages.
